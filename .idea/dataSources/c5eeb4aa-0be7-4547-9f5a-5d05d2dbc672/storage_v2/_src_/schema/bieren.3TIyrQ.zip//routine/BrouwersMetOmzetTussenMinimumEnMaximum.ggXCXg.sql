create
    definer = root@localhost procedure BrouwersMetOmzetTussenMinimumEnMaximum(IN min double, IN max double)
BEGIN
SELECT id, naam, adres, postcode, gemeente, omzet FROM brouwers WHERE omzet BETWEEN min AND max ORDER BY omzet;
END;

