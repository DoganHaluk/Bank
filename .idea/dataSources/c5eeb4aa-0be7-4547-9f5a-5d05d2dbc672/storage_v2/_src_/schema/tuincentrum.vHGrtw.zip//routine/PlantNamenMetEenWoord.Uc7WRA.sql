create
    definer = root@localhost procedure PlantNamenMetEenWoord(IN woord varchar(50))
begin
select naam from planten where naam like woord order by naam;
end;

